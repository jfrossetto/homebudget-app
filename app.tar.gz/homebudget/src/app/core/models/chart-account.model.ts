export interface IChartAccount {
    id?: string;
    code?: string;
    description?: string;
  }
  