import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reconcile-extract-container',
  templateUrl: './reconcile-extract-container.component.html',
  styleUrls: ['./reconcile-extract-container.component.scss']
})
export class ReconcileExtractContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
