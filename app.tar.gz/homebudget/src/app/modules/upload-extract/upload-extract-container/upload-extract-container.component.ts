import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-extract-container',
  templateUrl: './upload-extract-container.component.html',
  styleUrls: ['./upload-extract-container.component.scss']
})
export class UploadExtractContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
