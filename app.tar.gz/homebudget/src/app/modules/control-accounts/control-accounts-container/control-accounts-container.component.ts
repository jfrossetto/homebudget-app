import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-accounts-container',
  templateUrl: './control-accounts-container.component.html',
  styleUrls: ['./control-accounts-container.component.scss']
})
export class ControlAccountsContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
